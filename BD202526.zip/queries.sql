-- Responder as Querires aqui de Q1 a Q12

----------------------------------------------------------------------------------------------
-- Q1:Listar o nome e o NIF de todos os funcionários que trabalham com 'Cozinha'
----------------------------------------------------------------------------------------------

select p.nif, p.nome from pessoa p, funcionario f 
where p.nif = f.nif and f.categoria = 'Cozinha'; 

----------------------------------------------------------------------------------------------
-- Q2: Qual é a variadade de produtos existentes agrupados por tipo
----------------------------------------------------------------------------------------------

select p.tipo, count(p.tipo) from produto p 
group by p.tipo; 

----------------------------------------------------------------------------------------------
-- Q3: Listar as áreas de serviço que realizaram mais de uma venda no total 
----------------------------------------------------------------------------------------------

select c.id_aservico, a.nome, count(c.id_aservico) 
from compra c left join areadeservico a on c.id_aservico = a.id_aservico
group by c.id_aservico, a.nome having count(c.id_aservico) > 1;

----------------------------------------------------------------------------------------------
-- Q4: Listar todos os produtos registados e, se existirem, a quantidade total vendida de cada
-- um. Produtos nunca vendidos devem aparecer com quantidade de zero.
----------------------------------------------------------------------------------------------

select p.id_produto, p.nome,
case 
	when sum(l.quantidade) is null then 0
	else sum(l.quantidade)
end as quantidadeVendida
from produto p left join listadecompra l on p.id_produto = l.id_produto
group by p.id_produto order by quantidadevendida desc;

----------------------------------------------------------------------------------------------
-- Q5: Listar o nome e preco dos produtos cujo preço é superior ao preço médio de todos os 
-- produtos na loja.
----------------------------------------------------------------------------------------------

select p.nome, p.preco from produto p 
where p.preco > (
	select avg(preco) from produto
);

----------------------------------------------------------------------------------------------
-- Q6: Determinar qual foi a compra com o valor mais elevado registado no sistema
----------------------------------------------------------------------------------------------

with maior_preco(valor) as (
	select max(preco)
	from pagamento p 
	where p.id_compra is not null
)
select distinct maior_preco.valor as maior_compra, p.nif_pessoa, p.id_compra
from maior_preco, pagamento p left join listadecompra l on p.id_compra = l.id_compra
where p.preco = maior_preco.valor;

----------------------------------------------------------------------------------------------
-- Q7: Listar o nome das pessoas que são Sócios, mas que nunca se inscreveram em nenhuma aula.
----------------------------------------------------------------------------------------------

select p.nome, s.nif, s.id_socio, s.data_adesao from socio s left join pessoa p on p.nif = s.nif
where not exists (
	select distinct i.nif_socio from inscricaoaula i 
	where i.nif_socio = s.nif 
);

----------------------------------------------------------------------------------------------
-- Q8: Listar o nome de cada funcionário e o nome do respetivo chefe.
----------------------------------------------------------------------------------------------

select p.nome as "Funcionario", p1.nome as "Chefe" 
from funcionario f left join funcionario f1 on f.nif_chefe = f1.nif 
left join pessoa p on f.nif = p.nif 
left join pessoa p1 on f1.nif = p1.nif;

----------------------------------------------------------------------------------------------
-- Q9: Listar o nome dos Sócios que já se inscreveram em aulas de todas as modalidades 
-- disponíveis no clube (ex: Ténis e Padel).
----------------------------------------------------------------------------------------------

select p.nome from 
socio s left join pessoa p on s.nif = p.nif 
left join inscricaoaula i on s.nif = i.nif_socio 
left join aula a on i.id_aula = a.id_aula 
group by p.nome, p.nif having count(distinct a.modalidade) >= (
	select count(distinct a2.modalidade) from aula a2 
);

----------------------------------------------------------------------------------------------
-- Q10: Listar o nome e descrição de todos os produtos que contêm a palavra 'Raquete' no nome.
----------------------------------------------------------------------------------------------

select * from produto p 
where p.nome like '%Raquete%';

----------------------------------------------------------------------------------------------
-- Q11: Listar os produtos que são mais caros do que todos os produtos do tipo 'Bolas'
----------------------------------------------------------------------------------------------

select * from produto p 
where p.preco > all (
	select preco from produto 
	where tipo = 'Bolas'
);

----------------------------------------------------------------------------------------------
-- Q12: Listar o total faturado por cada funcionário através das vendas que realizou, 
-- mostrando o nome do funcionário, a área de serviço onde trabalha e o valor total faturado, 
-- ordenado de forma decrescente pelo valor faturado.
----------------------------------------------------------------------------------------------

select p.nome, a.nome as area_servico,
case
	when sum(preco) is null then 0
	else sum(preco)
end as Total
from 
funcionario f left join compra c on f.nif = c.nif_func 
left join pessoa p on f.nif = p.nif 
left join pagamento pa on pa.id_compra = c.id_compra 
left join areadeservico a on f.id_aservico = a.id_aservico 
group by f.nif, p.nome, a.nome order by Total desc; 





