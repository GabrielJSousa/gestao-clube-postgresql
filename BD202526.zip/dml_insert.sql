
insert into AreaDeServico (ID_AServico, nome, localidade) values 
	(1, 'Loja de Desporto', 'Edifício 1'),
	(2, 'Bar do Clube', 'Edifício 2'),
	(3, 'Armazém', 'Campo Principal');

	
insert into Pessoa (NIF, nome) values
	('100000001', 'Ana Silva'),
    ('100000002', 'Bruno Santos'),
    ('100000003', 'Carla Dias'),
    ('200000001', 'Daniel Costa'),
    ('200000002', 'Eva Lima'),
    ('200000003', 'Fábio Rui'),
    ('300000001', 'Gisela Nunes'),
    ('300000002', 'Hugo Martins'),
    ('400000001', 'Inês Ferreira'),
    ('400000002', 'João Pereira');

insert into PessoaContactos (NIF, contacto) values
	('100000001', '910000001'),
	('100000001', '911111111'),	
	('100000002', '910000002'),
	('200000001', '960000001'),
	('200000002', '930000002');

insert into Funcionario (NIF, id_func, salario, ID_AServico, NIF_chefe, Categoria) values 
	('100000001', 8819, 2037.60, 1, '100000002', 'Atendimento'),
	('100000002', 2405, 3502.26, 1, '200000003', 'Gerente'),
	('200000002', 8502, 3853.00, 2, '200000003', 'Gerente'),
	('200000003', 2454, 10350.00,null, null, 'Diretor' ),
	('300000002', 2850, 1857.94, 2, '200000002', 'Cozinha'),
	('400000001', 1100, 2132.53, 1, '100000002', 'Reposição');

	
insert into Socio (NIF, id_socio, Data_Adesao) values 
	('100000001', 9273, '2025-05-15'),
    ('100000002', 6197, '2025-11-20'),
    ('100000003', 1633, '2025-01-10'),
    ('200000001', 9683, '2025-08-05'),
    ('200000002', 8542, '2025-02-14'),
    ('200000003', 6546, '2025-04-01');



insert into Produto (id_produto, Nome, Descricao, Preco, Tipo) values
    (5970, 'Raquete Pro X', 'Raquete de Padel profissional', 150.00, 'Raquete'),
    (6308, 'Ténis RunFast', 'Calçado para terra batida', 89.90, 'Ténis'),
    (6112, 'Pack Bolas Padel', 'Tubo com 3 bolas de Padel', 5.50, 'Bolas'),
    (9775, 'T-shirt Técnica', 'Camisola respirável tamanho L', 19.99, 'Roupa'),
    (2027, 'Saco Desportivo', 'Mochila com compartimento para raquete', 45.00, 'Mochila'),
    (6685, 'Boné Clube', 'Boné com pala ajustável', 12.50, 'Roupa'),
    (3626, 'Pack Bolas Ténis', 'Tubo com 4 bolas de Ténis', 7.00, 'Bolas'),
    (3077, 'Água 0.5L', 'Garrafa de água mineral', 1.20, 'Bebida'),
    (6469, 'Sandes Mista', 'Pão caseiro com queijo e fiambre', 3.50, 'Comida'),
    (7899, 'Café Expresso', 'Café torrado intenso', 0.80, 'Bebida'),
    (4142, 'Compal', 'Sumo Compal', 1.80, 'Bebida');


insert into Stock (ID_Produto, ID_Aservico, Quantidade, qtd_minima) values
	(5970, 1, 10, 2),
    (6308, 1, 5, 1),
    (6112, 1, 50, 10),
    (9775, 1, 100, 20),
    (2027, 1, 20, 5),
    (6685, 1, 10, 2),
    (3626, 1, 23, 8),
    (3077, 2, 200, 24),
    (6469, 2, 15, 5),
    (7899, 2, 100, 20),
    (4142, 2, 0, 20),
    (3626, 3, 500, 50),
	(6112, 3, 500, 50);


insert into Compra (ID_Compra, nif_pessoa, nif_func, ID_Aservico, Data) values
    (1001, '200000001', '300000002', 2, '2025-11-28 18:30:00'),
    (1002, '100000001', '100000001', 1, '2025-11-29 10:15:00'),
    (1003, '200000001', '300000002', 2, '2025-11-30 18:30:00');



insert into ListaDeCompra (ID_Compra, ID_Produto, Quantidade) values 
    (1001, 3077, 2),
    (1001, 6469, 1),
    (1002, 6112, 5),
	(1003, 3077, 2);

insert into Pagamento (ID_Pagamento, nif_pessoa, ID_Compra, Data, preco, Tipo) values
    (1000, '200000001', 1001, '2025-11-28 18:35:00', 5.90, 'Dinheiro'),
    (2200, '100000001', 1002, '2025-11-29 10:20:00', 11.00, 'MBway'),
    (3000, '100000001', NULL, '2025-11-28 09:00:00', 30.00, 'Dinheiro'),
    (4000, '100000002', NULL, '2025-11-28 09:00:00', 30.00, 'MBway'),
    (5000, '100000003', NULL, '2025-11-30 14:00:00', 30.00, 'Dinheiro'),
    (6000, '200000001', NULL, '2025-12-01 08:30:00', 30.00, 'MBway');

insert into Aula (ID_Aula, nif_func, Data, Duracao, Modalidade, N_bolas) values
    (1, '100000002', '2025-12-01', '01:00:00', 'Padel', 20),
    (2, '100000002', '2025-12-02', '01:30:00', 'Ténis', 30),
    (3, '100000001', '2025-12-03', '01:00:00', 'Padel', 24);


insert into InscricaoAula (ID_Aula, nif_Socio, DataDeInscricao) values
    (1, '100000001', '2025-11-28'),
    (2, '100000001', '2025-11-28'),
    (1, '100000002', '2025-11-29'),
    (2, '100000003', '2025-11-30'),
    (3, '200000001', '2025-12-01');
