------------------------------------------------------------------------------------
-- V1: Uma view que permite visualizar todos os funcionarios sem o seu salário
------------------------------------------------------------------------------------

create or replace view RH as 
select p.nome, p.nif, a.nome as Servico, f.categoria from 
funcionario f left join pessoa p on f.nif = p.nif 
left join AreaDeServico a on f.id_aservico = a.id_aservico;

select * from RH;

------------------------------------------------------------------------------------
-- V2: Uma view que permite os clientes visualizar o catalogo, indicando se o 
-- produto esta em stock ou não
------------------------------------------------------------------------------------

create or replace view catalogo as
select p.nome, p.descricao, p.preco, p.tipo, s.id_aservico, 
case
	when s.quantidade > 0 then 'Em Stock'
	else 'Sem Stock'
end NoStock
from 
produto p left join stock s on p.id_produto = s.id_produto;

select nome, descricao, preco, tipo, nostock from catalogo
where id_aservico = 2;

------------------------------------------------------------------------------------
-- V3: Uma view para ver os sócios juntamente com os descontos que cada um tem
------------------------------------------------------------------------------------

create or replace view socios_com_desconto as 
select p.nome, p.nif, s.data_Adesao,
case
	when date_part('year', age(current_date, s.data_Adesao)) = 0 then 2
	when date_part('year', age(current_date, s.data_Adesao)) = 1 then 4
	when date_part('year', age(current_date, s.data_Adesao)) = 2 then 6
	when date_part('year', age(current_date, s.data_Adesao)) = 3 then 8
	when date_part('year', age(current_date, s.data_Adesao)) = 4 then 10
	else 15
end as Desconto
from socio s left join pessoa p on s.nif = p.nif;


select * from socios_com_desconto;


------------------------------------------------------------------------------------
-- V4: Uma view para ver a compra com preco_total()
------------------------------------------------------------------------------------

create or replace view compra_com_precoTotal as 
select c.id_compra, c.nif_pessoa, c.nif_func, c.id_aservico, 
sum(lc.quantidade * p.preco) * 
	(100.0 - case 
			when s.desconto is null then 0
			else s.desconto
		end) / 100.0 as preco_total
from compra c 
left join listadecompra lc on c.id_compra = lc.id_compra 
left join produto p on lc.id_produto = p.id_produto
left join socios_com_desconto s on c.nif_pessoa = s.nif
group by c.id_compra, c.nif_pessoa, c.nif_func, c.id_aservico, s.desconto;


select * from compra_com_precoTotal;


