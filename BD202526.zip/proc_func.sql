----------------------------------------------------------------------------------------------
-- Stored Preceudure para registar o pagamento da mensalidade de uma pessoa que já é um sócio,
-- ou se a pessoa não for um sócio, irá fazer o registo
----------------------------------------------------------------------------------------------


create or replace procedure registar_mensalidade (in nome varchar(100), in nif_pessoa varchar(10), in preco numeric(8,2), in tipo tipoPagamento)
as
$$
declare nif varchar(10);
declare s_nif varchar(10);
begin
	
	select p.nif into nif 
	from pessoa p
	where nif_pessoa = p.nif;

	select s.nif into s_nif 
	from socio s
	where nif_pessoa = s.nif;
	
	if nif is null then
		raise notice 'O Cliente não esta registado no sistema, registando...';
		insert into pessoa (nif, nome) values (nif_pessoa, nome);
		raise notice 'Cliente registado com SUCESSO';
	end if; 

	if s_nif is null then
		raise notice 'Registando Cliente como sócio...';		
		insert into Socio (NIF, Data_Adesao) values (nif_pessoa, current_date);
		raise notice 'Cliente registado com SUCESSO';
	end if;

	insert into pagamento (NIF_pessoa, ID_Compra, data, tipo, preco) values (nif_pessoa, null, current_date, tipo, preco);
	raise notice 'Mensalidade registada com SUCESSO';
	
end;
$$
language plpgsql;

call registar_mensalidade ('Guilherme Guerreiro', '220000001', 10.00, 'MBway');


----------------------------------------------------------------------------------------------
-- Stored Preceudure para registar uma compra de um único produto, 
-- por exemplo ir ao bar e comprar apenas café
----------------------------------------------------------------------------------------------

create or replace procedure compra_de_um_produto
(in nif_cliente varchar(10), in nif_f varchar(10), in id_area int, in id_p int, in quant int, in tipoP tipoPagamento)
as 
$$
declare pr numeric(8, 2);
declare id_c int;
declare des numeric;
begin

	select p.preco into pr
	from produto p
	where p.id_produto = id_p;

	if (pr is null) then
		raise exception 'O Produto não existe';
	end if;

	select s.desconto into des from socios_com_desconto s
	where s.nif = nif_cliente;
	
	if(des is null) then des = 1.0;
	else des = 1.0 - (des / 100);
	end if;
	

	insert into Compra (nif_pessoa, nif_func, ID_Aservico, Data) values
	(nif_cliente, nif_f, id_area, current_date)
	returning id_compra into id_c;

	insert into ListaDeCompra (ID_Compra, ID_Produto, Quantidade) values 
	(id_c, id_p, quant);

	insert into Pagamento (nif_pessoa, ID_Compra, Data, preco, Tipo) values
	(nif_cliente, id_c, current_date, pr * quant * des , tipoP);

	raise notice 'Venda registada com SUCESSO';
end;
$$
language plpgsql;


call compra_de_um_produto('220000001', '200000002', 2, 7899, 2, 'Dinheiro');
call compra_de_um_produto('400000002', '200000002', 2, 7899, 2, 'Dinheiro');

