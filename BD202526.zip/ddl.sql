drop table if exists inscricaoaula ;
drop table if exists aula;
drop table if exists listadecompra;
drop table if exists pagamento ;
drop table if exists compra ;
drop table if exists stock;
drop table if exists pessoacontactos;
drop table if exists socio;
drop table if exists funcionario ;
drop table if exists produto;
drop table if exists areadeservico;
drop table if exists pessoa;


create domain tipoTrabalho varchar(15)
	check (value in ('Reposição', 'Atendimento', 'Limpeza', 'Cozinha', 'Gerente', 'Diretor'));

create domain tipoProduto varchar(10)
	check (value in ('Raquete', 'Ténis', 'Roupa', 'Bolas', 'Mochila', 'Comida', 'Bebida'));

create domain modalidade varchar(10)
	check (value in ('Ténis', 'Padel'));

create domain tipoPagamento varchar(10)
	check (value in ('Dinheiro', 'Cartão', 'MBway', 'Mensal'));



-- Pessoa (NIF, nome)
create table Pessoa(
	NIF varchar(10),
	nome varchar(100) not null,
	
	primary key(NIF)
);

create table PessoaContactos(
	NIF varchar(10),
	contacto varchar(10),
	
	primary key (NIF, contacto),
	foreign key (NIF) references Pessoa
);

-- ÁreaDeServiço(ID_Aserviço, nome, localidade)
create table AreaDeServico(
	ID_AServico int,
	nome varchar(100) not null,
	localidade varchar(200) not null,
	
	primary key (ID_AServico)
);


-- Funcionário (NIF, ID_func, salário, ID_AServiço, NIF_chefe, Categoria, Turno)
create table Funcionario(
	NIF varchar(10),
	ID_func int unique not null ,
	salario numeric(8,2),
	ID_AServico int,
	NIF_chefe varchar(10),
	categoria tipoTrabalho not null,
	
	primary key (NIF),
	foreign key (NIF) references Pessoa,
	foreign key (NIF_chefe) references Funcionario,
	foreign key (ID_AServico) references AreaDeServico,
	
	check (salario >= 0),
	check ((categoria = 'Diretor' and nif_chefe is null and ID_AServico is null) or 
	(categoria <> 'Diretor' and nif_chefe is not null and ID_AServico is not null))
);


-- Sócio (NIF, ID_Sócio, Data_Adesão)
create table Socio(
	NIF varchar(10),
	ID_socio serial unique not null,
	data_Adesao date not null,
	
	primary key (NIF),
	foreign key (NIF) references Pessoa
);



-- Compra (ID_Compra, nif_pessoa, nif_func, ID_Aserviço, Data)
create table Compra(
	ID_Compra serial,
	NIF_pessoa varchar(10),
	NIF_func varchar(10) not null,
	ID_AServico int not null,
	data timestamp not null,
	
	primary key (ID_Compra),
	foreign key (NIF_pessoa) references Pessoa,
	foreign key (NIF_func) references Funcionario,
	foreign key (ID_AServico) references AreaDeServico
);

-- Produto (ID_Produto, Nome, Descrição, Preço, Tipo)
create table Produto(
	ID_Produto int,
	nome varchar(20) not null,
	descricao varchar(200) not null,
	preco numeric(8, 2) not null,
	tipo tipoProduto not null,
	
	primary key (ID_Produto),
	
	check (preco >= 0)
);

-- Pagamento (ID_Pagamento, ID_pessoa, ID_Compra, Data, Tipo, preco)
create table Pagamento(
	ID_Pagamento serial,
	NIF_pessoa varchar(10),
	ID_Compra int,
	data timestamp not null,
	tipo tipoPagamento not null,
	preco numeric(8,2) not null,
	
	primary key (ID_Pagamento),
	foreign key (NIF_pessoa) references Pessoa,
	foreign key (ID_Compra) references Compra,
	
	check (id_compra is not null or nif_pessoa is not null),
	check (preco > 0)
	
	
);

-- Aula(ID_Aula, ID_func, Data, Duração, Modalidade, N_bolas)
create table Aula(
	ID_Aula int,
	NIF_func varchar(10) not null,
	data date not null, 
	duracao time not null,
	modalidade modalidade not null,
	N_bolas int not null, 
	
	primary key (ID_Aula),
	foreign key (NIF_func) references Funcionario,
	
	check (N_bolas >= 0)
	
);


-- Stock (ID_Produto, ID_Aserviço, Quantidade, NúmeroMínimo)
create table Stock (
	ID_Produto int, 
	ID_AServico int, 
	quantidade int not null,
	qtd_minima int,
	
	primary key (ID_Produto, ID_AServico),
	foreign key (ID_Produto) references Produto,
	foreign key (ID_AServico) references AreaDeServico,
	
	check (qtd_minima >= 0),
	check (quantidade >= 0)
);


-- ListaDaCompra (ID_compra, ID_Produto, Quantidade)
create table ListaDeCompra(
	ID_Compra int,
	ID_Produto int,
	quantidade int not null,
	
	primary key (ID_Compra, ID_Produto),
	foreign key (ID_Compra) references Compra,
	foreign key (ID_Produto) references Produto,
	
	check (quantidade > 0)
);


-- InscriçãoAula (ID_Aula, ID_Sócio, DataDeInscrição)

create table InscricaoAula (
	ID_Aula int,
	NIF_Socio varchar(10),
	dataDeInscricao timestamp not null,
	
	primary key (ID_Aula, NIF_Socio),
	foreign key (ID_Aula) references Aula,
	foreign key (NIF_Socio) references Socio
);


------------------------------------------------------------------------------------
-- T1: Verificar a quantidade dos produtos quando esta a ser efetuado a compra, 
-- não é possivel comprar mais quantidade de um produto dq há em stock
------------------------------------------------------------------------------------

create or replace function verificar_quantidade()
returns trigger as 
$$
declare q int;
begin
	select quantidade into q
	from stock 
	where id_produto = new.id_produto;

	if(q is null or q = 0 or new.quantidade > q) 
		then raise exception 'O produto não se encontra em stock, não existe ou a quantidade a ser comprada é maior que a que se encontra em stock';
	end if;

	return new;

end;
$$
language plpgsql;


create trigger verificar_quantidade_ListaDeCompra 
before insert or update on ListaDeCompra
for each row 
execute function verificar_quantidade();


------------------------------------------------------------------------------------
-- T2: Trigger para atualizar a quantidade quando alguma produto é comprado
------------------------------------------------------------------------------------

create or replace function atualizar_quantidade()
returns trigger as
$$
declare q int;
declare a int;
begin
	select quantidade into q
	from stock
	where id_produto = new.id_produto;

	select id_aservico into a
	from compra 
	where id_compra = new.id_compra;
	
	update stock set quantidade = q - new.quantidade 
	where id_produto = new.id_produto and id_aservico = a;

	return new;
end;
$$
language plpgsql;


create  or replace trigger atualizar_quantidade_no_stock
after insert or update on ListaDeCompra
for each row
execute function atualizar_quantidade();

------------------------------------------------------------------------------------
-- T3: Trigeer para avisar quando a quantidade de um produto chega ao limite minimo 
-- defenido
------------------------------------------------------------------------------------

create or replace function aviso_quantidade_minima()
returns trigger as
$$
declare n varchar(20);
declare na varchar(100);
begin
	
	if new.quantidade <= new.qtd_minima then 
	
		select nome into n from produto
		where new.id_produto = id_produto;
	
		select nome into na from AreaDeServico
		where new.id_aservico = id_aservico;
		
		raise notice 'O produto "%" no stock da area % apenas tem a quantidade restante de %', n, na, new.quantidade;
		
	end if;
	
	return new;
end
$$
language plpgsql;

create or replace trigger avisar_minima_quantidade
after insert or update on stock
for each row
execute function aviso_quantidade_minima();


------------------------------------------------------------------------------------
-- T4: Um triger para verificar se o sócio pagou mensalidade para poder participar 
-- nas aulas
------------------------------------------------------------------------------------


create or replace function verificar_se_pode_participar()
returns trigger as
$$
declare d date;
declare d_aula date;
begin
	select data into d_aula
	from Aula a
	where a.id_aula = new.id_aula;

	select max(data) into d 
	from pagamento p
	where p.nif_pessoa = new.nif_socio and p.id_compra is null and p.data <= d_aula;


	if (d is null) then
		raise exception 'O sócio não pagou a mensalidade deste mês';
	end if;


	if (d_aula > (d + interval '1 month')) then
		raise exception 'O sócio não pagou a mensalidade deste mês';
	end if;


	return new;
end
$$
language plpgsql;


create or replace trigger aviso_inscricao_aula
before insert or update on InscricaoAula
for each row 
execute function verificar_se_pode_participar();

------------------------------------------------------------------------------------
-- T5: Um trigger para gerenciar as bolas usadas nas Aulas
------------------------------------------------------------------------------------

create or replace function bolas_para_aulas()
returns trigger as
$$
declare id_bolas int;
declare id_armazem int = 3;
begin
	if (new.modalidade = 'Ténis') then id_bolas = 3626;
	elseif (new.modalidade = 'Padel') then id_bolas = 6112;
	else return new;
	end if;

	update stock
	set quantidade = quantidade - new.N_bolas
	where ID_AServico = id_armazem and id_bolas = id_produto;
	
	return new;
end
$$
language plpgsql;

create or replace trigger verificar_bolas_para_aulas
after insert on aula
for each row
execute function bolas_para_aulas();

